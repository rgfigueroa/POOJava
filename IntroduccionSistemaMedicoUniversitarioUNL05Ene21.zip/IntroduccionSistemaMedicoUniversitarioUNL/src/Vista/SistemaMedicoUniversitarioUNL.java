/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.ControladorMedico;
import Modelo.Medico;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author roberth
 */
public class SistemaMedicoUniversitarioUNL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("SISTEMA MEDICO UNIVERSITARI UNL");
        System.out.println("patron de diseño MVC");
       
        ArrayList<Medico> listadoMedico = new ArrayList<Medico>();

        ControladorMedico ctrlMedico = new ControladorMedico();
        ctrlMedico.mostrarInformacionMedico();

        Medico objMedico = ctrlMedico.mostrarInformacionMedico();

        Medico objMedico2 = ctrlMedico.mostrarInformacionMedico();

        listadoMedico.add(objMedico);
        listadoMedico.add(objMedico2);

        listadoMedico.forEach(m -> System.out.println(m.getNombre() + m.getFechaIngreso()));

        /*
        GregorianCalendar gc = new GregorianCalendar();
        Date fechaI = gc.getTime();

        Medico medico = new Medico("Medico Internista Juan Perez", fechaI);
        System.out.println("La fecha de ingreso es" + fechaI);

        System.out.println("El año de ingreso" + fechaI.getYear());
        System.out.println("El año de ingreso" + fechaI.getMonth());
        System.out.println("El año de ingreso" + fechaI.getDay());

        int anio = Calendar.getInstance().get(Calendar.YEAR);
        int mes = Calendar.getInstance().get(Calendar.MONTH+1);
        int dia = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
        
        
        System.out.println("El año de ingreso" + Calendar.getInstance().get(Calendar.YEAR));
        System.out.println("El mes es" + Calendar.getInstance().get(Calendar.MONTH));
        System.out.println("El mes es" + Calendar.getInstance().get(Calendar.HOUR_OF_DAY));
        System.out.println("La fecha de ingreso es:" + dia+":"+mes+":"+anio);

        Date fd = gc.getTime();
        
        Medico medico2 = new Medico("Medico2",fd);
         */
//        System.out.println(medico.getNombre());
//        ControladorMedico ctrlMedico= new ControladorMedico();
//        String va= ctrlMedico.agendarTurno();
//        System.out.println("El turno cambiado es:"+va);
    }

}
