/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Medico;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author roberth
 */
public class ControladorMedico {

    public void operar() {
        System.out.println("Metodo operacion");
    }

    public String agendarTurno() {
        System.out.println("Agendando un turno: El turno de las 16h00");
        return "Turno de las 17h30";
    }

    public Medico mostrarInformacionMedico() {
        System.out.println("Información del Medico");

        GregorianCalendar gc = new GregorianCalendar();
        Date fechaI = gc.getTime();

        int hora = fechaI.getHours();
        System.out.println("Hora:" + hora);

        System.out.println("Mostrar:" + Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + ":" + Calendar.getInstance().get(Calendar.MINUTE) + ":" + Calendar.getInstance().get(Calendar.SECOND));

        Medico medico = new Medico("Medico Internista Juan Perez", fechaI);

        int turno = (int) (Math.random() * 100 + 1);

        System.out.println("Generación de turno aleatorio" + turno);
        System.out.println("La fecha de ingreso es" + fechaI);
        
        return medico;

    }

}
