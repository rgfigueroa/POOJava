/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.ControladorPersona;
import Modelo.Persona;

/**
 *
 * @author roberth
 */
public class SistemaImprentaMVC2A {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            String claveDesdeArchivo = "";
            Persona pUsuario = new Persona("Juan", "juan@unl.edu.ec", "Juan", "12345");
            ControladorPersona ctrlPersona = new ControladorPersona();
            claveDesdeArchivo = ctrlPersona.leerClave();
            ctrlPersona.autenticar(pUsuario.getUsername(), claveDesdeArchivo);
        } catch (Exception e) {
            e.getMessage();
        }

    }

}
