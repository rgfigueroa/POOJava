/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author roberth
 */
public class ControladorPersona {

    public boolean autenticar(String username, String password) {
        String clave = "12345";
        if (clave.equals(password) && username.equals("Juan")) {
            System.out.println("Bienvenido....ingresa! " + username);
            return true;

        } else {
            System.out.println("Clave incorrecta");
            System.out.println("No puedes ingresar");
            return false;
        }

    }

    public String leerClave() {
        String entrada = "";
        try {
            File f = new File("Datos.txt");           
            Scanner sc = new Scanner(f);
            while (sc.hasNextLine()) {
                entrada = sc.nextLine();
                System.out.println("datos leidos desde el archivo -->" + entrada);
            }
            sc.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ControladorPersona.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("El archivo no se ha encontrado");
        } finally {
            System.out.println("Se ha leido los datos");
        }
        return entrada;
    }
}
