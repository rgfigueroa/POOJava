/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.HisotriaClinia;

/**
 *
 * @author roberth
 */
public class ControladorMedico {

    public boolean recetar(HisotriaClinia hc) {
        System.out.println("Logica para realizar la Receta con codigo: "+ hc.getCodigo());
        return true;
    }

}
