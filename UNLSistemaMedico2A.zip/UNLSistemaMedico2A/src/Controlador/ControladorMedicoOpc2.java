/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Medico;
import java.util.Date;

/**
 *
 * @author roberth
 */
public class ControladorMedicoOpc2 extends  Medico{
    
    public ControladorMedicoOpc2(String nombre, Date fechaNacimiento, Date fechaIngreso) {
        super(nombre, fechaNacimiento, fechaIngreso);
    }
    @Override
    public void reservarTurno() {
        System.out.println("Logica para Reservar El Turno desde el ControladorMedicoOpc2");
    }
    
}
