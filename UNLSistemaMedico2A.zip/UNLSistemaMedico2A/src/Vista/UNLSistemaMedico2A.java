/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.ControladorMedico;
import Controlador.ControladorMedicoOpc2;
import Modelo.HisotriaClinia;
import Modelo.Medico;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author roberth
 */
public class UNLSistemaMedico2A {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here    

        Date fecha;
        GregorianCalendar gc = new GregorianCalendar();
        fecha = gc.getTime();
               
        ControladorMedicoOpc2 ctrlMedicoOpc2 = new ControladorMedicoOpc2("Dr.juaito", fecha, fecha);
        ctrlMedicoOpc2.sueldo();
        ctrlMedicoOpc2.reservarTurno();
        
        
        try {
            Controlador.ControladorMedico ctrlMedico = new ControladorMedico();
            boolean respuesta = false;

            respuesta = ctrlMedico.recetar(new HisotriaClinia(1));
            if (respuesta) {
                System.out.println("Receta realizada");
            } else {
                System.out.println("No es posible Recetar");

            }
        } catch (Exception e) {
            System.out.println("Error al recetar revisar falla: " + e.getMessage());
        }

    }

}
