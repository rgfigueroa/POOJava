/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Date;

/**
 *
 * @author roberth
 */
public class Medico extends Empleado implements InterfaceTurno {

    private int matriculaMedica;

    public Medico(String nombre, Date fechaNacimiento, Date fechaIngreso) {
        super(nombre, fechaNacimiento, fechaIngreso);
    }

    /**
     * @return the matriculaMedica
     */
    public int getMatriculaMedica() {
        return matriculaMedica;
    }

    /**
     * @param matriculaMedica the matriculaMedica to set
     */
    public void setMatriculaMedica(int matriculaMedica) {
        this.matriculaMedica = matriculaMedica;
    }

    @Override
    public void reservarTurno() {
        System.out.println("Logica para Reservar El Turno desde Modelo");
    }

    @Override
    public void eliminarTurno() {
        System.out.println("Logica para Reservar El Turno");

    }

}
