/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Date;

/**
 *
 * @author roberth
 */
public class Paciente extends Persona {

    HisotriaClinia historiaClinica;

    public Paciente(String nombre, Date fechaNacimiento, HisotriaClinia hc) {
        super(nombre, fechaNacimiento);
        this.historiaClinica = hc;
    }

    @Override
    public void sueldo() {
        //puede quedar sin logica o vacio
    }

}
