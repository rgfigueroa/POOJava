/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author roberth
 */
public class HisotriaClinia {

    private int codigo;

    public HisotriaClinia(int codigo) {
        //int aleatorio = (int) Math.random()*100+1;
        this.codigo = codigo;
    }
    

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

}
