/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Date;

/**
 *
 * @author roberth
 */
public class Empleado extends Persona {

    private Date fechaIngreso;

    public Empleado(String nombre, Date fechaNacimiento, Date fechaIngreso) {
        super(nombre, fechaNacimiento);
        this.fechaIngreso = fechaIngreso;
    }

    /**
     * @return the fechaIngreso
     */
    public Date getFechaIngreso() {
        return fechaIngreso;
    }

    /**
     * @param fechaIngreso the fechaIngreso to set
     */
    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    @Override
    public void sueldo() {
        //Implemenetar su logica
    }

}
