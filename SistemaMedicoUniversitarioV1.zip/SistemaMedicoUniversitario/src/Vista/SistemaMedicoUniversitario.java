/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.CtrlCitaMedica;
import Controlador.CtrlMedico;
import Modelo.CitaMedica;
import Modelo.Medico;
import Modelo.Paciente;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 *
 * @author roberth
 */
public class SistemaMedicoUniversitario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Medico> listaMedicos = new ArrayList<>();
        //ArrayList<CitaMedica> listadoCitasMedicas = new ArrayList<>();

        Scanner sc = new Scanner(System.in);
        System.out.println("====================== MENU SISTEMA MEDICO UNIVERSITARIO ======================");

        int opcion = 0;
        Date fecha;
        GregorianCalendar gc = new GregorianCalendar();

        System.out.println("Fecha del sistema:" + gc.getTime());

        fecha = gc.getTime();
        try {
            do {
                System.out.println("==== 1. Registrar información                 ====");
                System.out.println("==== 2. Eliminar Información                  ====");
                System.out.println("==== 3. Mostrar datos de medicos y citamedica ====");
                System.out.println("==== 4. Guardar información en Archivo        ====");
                System.out.println("==== 5. Salir                                 ====");
                System.out.println("==================================================");

                opcion = sc.nextInt();
                switch (opcion) {
                    case 1:
                        System.out.println("En 1. Registrar información");
                         {
                            int op = 0;
                            do {
                                System.out.println("==== 1. Registrar Medico                 ====");
                                System.out.println("==== 2. Registrar Cita Medica .          ====");
                                System.out.println("==== 3. Regresar al menu anterior        ====");

                                op = sc.nextInt();
                                switch (op) {
                                    case 1:
                                        System.out.println("Ingresando informacion del Medico");
                                        System.out.println("Identificaicon medico");
                                        String identificacionM = sc.next();
                                        System.out.println("Nombre");
                                        String nombreM = sc.next();
                                        System.out.println("especialidad");
                                        String especilidad = sc.next();
                                        System.out.println("Nombre del paciente");
                                        String nombrePaciente = sc.next();

                                        Paciente paciente = new Paciente("110405683", nombrePaciente, fecha, 1);
                                        CitaMedica citaMedica = new CitaMedica(1, fecha, 30, paciente);
                                        CtrlMedico ctrlMedico = new CtrlMedico();
                                        Medico medico = new Medico(identificacionM, nombreM, fecha, especilidad, new ArrayList<CitaMedica>() );

                                        ctrlMedico.agendarCitaMedica(medico, citaMedica);
                                        //medico.setListadoCitasMedicas(listadoCitasMedicas);
                                        listaMedicos.add(medico);
                                    case 2:
//                                        System.out.println("Ingresando informacion de Cita Medica");
//                                        System.out.println("Numero de cita");
//                                        int numeroVuelo = sc.nextInt();
//                                        System.out.println("Duracion");
//                                        int duracion = sc.nextInt();

                                    //  Vuelo v = new Vuelo(numeroVuelo, duracion, costo, origen, destino, listaPasajero);
                                }
                            } while (op != 3);
                        }
                        break;

                    case 2:
                        System.out.println("En 2. Eliminar Información");
                        break;
                    case 3:
                        System.out.println("En 3. Mostrar datos de medicos y cita medicas");
                        for (Medico medico : listaMedicos) {
                            System.out.println("Medico: " + medico.getNombre() + " " + medico.getEspecialidad());
                            System.out.println("Lista las Cita Medicas agendadas: ");
                            System.out.println("Usando un for de objetos: ");
                            for (CitaMedica c : medico.getListadoCitasMedicas()) {
                                System.out.println("Cita" + c.getPaciente().getNombre() + " " + c.getHoraCita());
                            }
//                            System.out.println("Usando un for mediante Notación Lambda: ");
//
//                            medico.getListadoCitasMedicas().forEach(lc -> System.out.println(lc.getPaciente().getNombre()));
                        }

                        break;
                    case 4:
                        System.out.println("En 4. Implemtar Guardar información en Archivo");
                        break;
                    case 5:
                        System.out.println("En 5. Salir");
                        break;
                    default:
                        System.err.println("Opcion no valida, vuelva a Seleccionar");
                }
            } while (opcion != 5);

        } catch (ArithmeticException ex) {
            System.out.println("El formato ingresado del dato es incorrecto\n" + ex.getMessage());
        } catch (Exception e) {
            System.out.println("Ocurrio un error que debes controlar" + e.getMessage());
        }

    }

}
