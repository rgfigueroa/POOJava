/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author roberth
 */
public class Medico extends Persona {

    private Date fechaIngreso;
    private String especialidad;
    private String sueldo;
    private ArrayList<CitaMedica> listadoCitasMedicas;

    public Medico(String identificacion, String nombre, Date fechaNacimiento, String especialidad) {
        super(identificacion, nombre, fechaNacimiento);
        this.especialidad = especialidad;

    }

    public Medico(String identificacion, String nombre, Date fechaNacimiento, String especialidad, ArrayList<CitaMedica> listadoCitasMedicas) {
        super(identificacion, nombre, fechaNacimiento);
        this.especialidad = especialidad;
        this.listadoCitasMedicas = listadoCitasMedicas;

//        try {
//            for (CitaMedica l : listadoCitasMedicas) {
//                System.out.println("Imprimir en: " + l.getPaciente().getNombre());
//            }
//        } catch (Exception e) {
//            e.getMessage();
//        }

    }

    /**
     * @return the fechaIngreso
     */
    public Date getFechaIngreso() {
        return fechaIngreso;
    }

    /**
     * @param fechaIngreso the fechaIngreso to set
     */
    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    /**
     * @return the especialidad
     */
    public String getEspecialidad() {
        return especialidad;
    }

    /**
     * @param especialidad the especialidad to set
     */
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    /**
     * @return the sueldo
     */
    public String getSueldo() {
        return sueldo;
    }

    /**
     * @param sueldo the sueldo to set
     */
    public void setSueldo(String sueldo) {
        this.sueldo = sueldo;
    }

    /**
     * @return the listadoCitasMedicas
     */
    public ArrayList<CitaMedica> getListadoCitasMedicas() {
        return listadoCitasMedicas;
    }

    /**
     * @param listadoCitasMedicas the listadoCitasMedicas to set
     */
    public void setListadoCitasMedicas(ArrayList<CitaMedica> listadoCitasMedicas) {
        this.listadoCitasMedicas = listadoCitasMedicas;
    }

}
