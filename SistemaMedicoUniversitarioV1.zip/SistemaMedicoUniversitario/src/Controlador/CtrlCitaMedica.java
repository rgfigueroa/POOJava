/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.CitaMedica;
import Modelo.Medico;

/**
 *
 * @author roberth
 */
public class CtrlCitaMedica {

    public void agendarTurno(Medico medico, CitaMedica citaMedica) {
        System.out.println("Agendando cita medica para el medico " + medico.getNombre());
//        medico.setCitaMedica(citaMedica);
//        System.out.println("Cita Medica"+citaMedica.getNumeroTurno());
//       
//        System.out.println("Costo de la cita:"+(medico.getCitaMedica().getNumeroTurno() * 30) );

    }

}
