/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.CitaMedica;
import Modelo.Medico;
import java.util.ArrayList;

/**
 *
 * @author roberth
 */
public class CtrlMedico {

    /**
     * Metodo que permite agendar una citaMedica a un medico señalado.
     *
     * @param medico
     * @param citaMedica
     * @return Retorna una lista de CitasMedicas
     */
    public ArrayList<CitaMedica> agendarCitaMedica(Medico medico, CitaMedica citaMedica) {
        ArrayList<CitaMedica> listaCM = new ArrayList<>();
        medico.getListadoCitasMedicas().add(citaMedica);
        return medico.getListadoCitasMedicas();
    }

    public ArrayList<CitaMedica> eliminarCitaMedica(Medico medico, CitaMedica citaMedica) {
        ArrayList<CitaMedica> listaCM = new ArrayList<>();
        medico.getListadoCitasMedicas().remove(citaMedica);
        return medico.getListadoCitasMedicas();
    }

}
