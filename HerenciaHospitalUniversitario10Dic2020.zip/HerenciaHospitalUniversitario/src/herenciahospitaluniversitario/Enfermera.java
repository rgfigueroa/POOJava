/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

/**
 *
 * @author roberth
 */
public class Enfermera extends Empleado {

    private char asistirCirugia;

    public Enfermera(String nombre, int horasDiarias, double salario) {
        super(nombre, horasDiarias, salario);
    }

    public Enfermera(String nombre, int horasDiarias, double salario, char asistirCirugia) {
        super(nombre, horasDiarias, salario);
        this.asistirCirugia=asistirCirugia;
    }

    /**
     * @return the asistirCirugia
     */
    public char getAsistirCirugia() {
        return asistirCirugia;
    }

    /**
     * @param asistirCirugia the asistirCirugia to set
     */
    public void setAsistirCirugia(char asistirCirugia) {
        this.asistirCirugia = asistirCirugia;
    }

}
