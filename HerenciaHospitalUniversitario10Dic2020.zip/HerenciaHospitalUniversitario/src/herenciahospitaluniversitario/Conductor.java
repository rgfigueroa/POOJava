/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

/**
 *
 * @author roberth
 */
public class Conductor extends Empleado {

    private String licencia;

    public Conductor(String nombre, int horasDiarias, double salario) {
        super(nombre, horasDiarias, salario);
    }

    public Conductor(String nombre, int horasDiarias, double salario, String licencia) {
        super(nombre, horasDiarias, salario);
        this.licencia= licencia;
    }

    /**
     * @return the licencia
     */
    public String getLicencia() {
        return licencia;
    }

    /**
     * @param licencia the licencia to set
     */
    public void setLicencia(String licencia) {
        this.licencia = licencia;
    }

}
