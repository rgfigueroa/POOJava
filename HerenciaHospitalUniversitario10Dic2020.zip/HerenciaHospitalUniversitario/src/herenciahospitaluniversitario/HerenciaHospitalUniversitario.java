/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author roberth
 */
public class HerenciaHospitalUniversitario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner scanner = new Scanner(System.in);
        JOptionPane.showInputDialog(null,"Hola");
        JOptionPane.showMessageDialog(null,"Hola salida");
        int op = 0;

        ArrayList<Empleado> listaEmp = new ArrayList<>();

        System.out.println("SISTEMA MEDICO UNIVERSITARIO UNL");

        do {
            System.out.println("Opcion 1. Crear un nuevo Empleado");
            System.out.println("Opcion 2. Mostrar el listado de Empleado");
            System.out.println("Opcion 3. Eliminar un Empleado");
            System.out.println("Opcion 4. Crear una factura");
            System.out.println("Opcion 5. Salir");
            op = scanner.nextInt();
            switch (op) {
                case 1:
                    System.out.println("Creación de nuevo empleado");
                    System.out.println("Ingreso nombre");
                    String nombre = scanner.next();
                    System.out.println("Ingreso numero de horas diarias");
                    int horasD = scanner.nextInt();
                    System.out.println("Valor salio básico");
                    double salarioBasico = scanner.nextDouble();
                    Empleado emp = new Empleado(nombre, horasD, salarioBasico);
                    listaEmp.add(emp);
                    break;
                case 2:
                    System.out.println("Mostrar el listado de Empleado");

                    for (Empleado e : listaEmp) {
                        System.out.println("Empleado:" + e.getNombre() + " tiene un salario básico de: " + e.getSalario()
                                + " y trabaja " + e.getHorasDiarias() + " diariamente.");
                    }
                    break;
                case 3:
                    System.out.println("Eliminar un Empleado");

                    // listaEmp.remove(emp);
                    break;
                case 4:
                    System.out.println("Crear una factura");
                    break;
                case 5:
                    System.out.println("Saliendo del programa");
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }

        } while (op <= 4);

        /*
        //Creacion de empleados
        Empleado empleado = new Empleado("Juan Perez", 8, 400.00);
        Medico medico = new Medico("Pediatra", "Dr. Pedro", 12, 600.00);
        Secretaria secretaria = new Secretaria("Maria", 6, 450.00);
        Conductor conductor = new Conductor("Conductor Luis", 6, 440.00, "Licencia D");

        ArrayList<Empleado> listaEmpleados = new ArrayList<>();
        listaEmpleados.add(empleado);
        listaEmpleados.add(medico);
        listaEmpleados.add(secretaria);
        listaEmpleados.add(conductor);

        System.out.println("Sueldo Basicos");
        for (Empleado e : listaEmpleados) {
            System.out.println("Empleado:" + e.getNombre() + " tiene un salario básico de: " + e.getSalario()
                    + " y trabaja " + e.getHorasDiarias() + " diariamente.");
        }

        System.out.println("Calculo de sueldo extra");

        for (Empleado e : listaEmpleados) {
            double sueldoAdicional = e.calcularSueldoExtra(10);
            double sueldoTotal = sueldoAdicional + e.getSalario();
            System.out.println("Sueldo totl es:" + sueldoTotal);
            e.setSalario(sueldoTotal);
        }

        System.out.println("Sueldo Tatales");

        for (Empleado e : listaEmpleados) {
            System.out.println("Empleado:" + e.getNombre() + " tiene un salario básico de: " + e.getSalario()
                    + " y trabaja " + e.getHorasDiarias() + " diariamente.");
        }

        System.out.println("Sueldo Tatales");
        double sueldoTotal = 0.0;
        for (Empleado e : listaEmpleados) {
            sueldoTotal = sueldoTotal + e.getSalario();
        }
        System.out.println("Sueldo Tatales de nomina a cancelar es:\t" + sueldoTotal);
       */
    }

}
