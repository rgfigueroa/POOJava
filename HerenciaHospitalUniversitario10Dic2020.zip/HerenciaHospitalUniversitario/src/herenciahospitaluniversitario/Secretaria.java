/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

/**
 *
 * @author roberth
 */
public class Secretaria extends Empleado {

    public Secretaria(String nombre, int horasDiarias, double salario) {
        super(nombre, horasDiarias, salario);
    }

    public void facturar(String nombre, double monto) {
        System.out.println("Generando Factura");
        double valorIva = monto * 0.12;
        double total = monto+valorIva;
        System.out.println("Al Cliente:"+nombre+"se debe factura el monto de:"+ total);
    }
}
