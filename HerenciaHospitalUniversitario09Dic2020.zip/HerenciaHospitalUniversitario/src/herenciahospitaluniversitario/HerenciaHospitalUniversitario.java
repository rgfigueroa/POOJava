/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

import java.util.ArrayList;

/**
 *
 * @author roberth
 */
public class HerenciaHospitalUniversitario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Empleado empleado1 = new Empleado();
        System.out.println(empleado1.getSalario());
        empleado1.setNombre("Pedro");

        System.out.println(empleado1.getNombre());

        Empleado empleadodos = new Empleado("EmpleadoDos", 400.00);
        System.out.println(empleadodos.getSalario());
        System.out.println(empleadodos.getNombre());

        Medico medico = new Medico();
        System.out.println(medico.getSalario());
        System.out.println(medico.getEspecialidad());

        Empleado empleadoJean = new Empleado("Jean", 448.00);
        empleadoJean.calcularSueldo();

        Empleado empledoJeanDos = new Medico("Doctor en Pediatría"); //
        empledoJeanDos.getSalario();

        System.out.println("Objeto generado de la clase:" + empleadoJean.getClass());
        System.out.println("Objeto generado de la clase:" + empledoJeanDos.getClass());
        System.out.println("Objeto generado de la clase:" + medico.getClass());

        Empleado empleadoJuan = new Empleado();
        empleadoJuan.setNombre("Empleado Juanito");
        Empleado empleadoCarlos = new Empleado("Carlos", 444.00);
        System.out.println(empleadoJuan.getSalario());
        System.out.println(empleadoCarlos.getSalario());

        Medico medico1 = new Medico();
        Medico medico2 = new Medico("Ginecólogo", "Dr Juan Perez", 600.00);
        medico1.recetar();
        System.out.println(medico1.getSalario());
        System.out.println(medico2.getSalario());

        Secretaria secre = new Secretaria("Secretaria Maria", 400.00);

        Empleado secre2 = new Secretaria("Secre 2", 300.00);

        System.out.println("Por favor Secretaria realizar: ");
        System.out.println("Nombre: " + secre.getNombre() + "y Salario de:" + secre.getSalario());
        secre.facturar();

        System.out.println(secre2.getClass());
        System.out.println(secre.getClass());

        Empleado[] listaEmpleado = new Empleado[4];
        listaEmpleado[0] = empleadoJuan;
        listaEmpleado[1] = empleadoCarlos;
        listaEmpleado[2] = secre;
        listaEmpleado[3] = empleadoJean;

        for (int i = 0; i < listaEmpleado.length; i++) {
            System.out.println("Empleado pos:[" + i + "]" + listaEmpleado[i].getNombre());
        }
        System.out.println("Mediante un for each:");

        for (Empleado e : listaEmpleado) {
            System.out.println("Empleado en la lista: " + e.getNombre() + "---->" + e.getSalario());
        }

        ArrayList<Empleado> listaEmpleadosGenerica = new ArrayList<>();
        listaEmpleadosGenerica.add(empleadoJuan);
        listaEmpleadosGenerica.add(empleadoCarlos);
        listaEmpleadosGenerica.add(secre);
        listaEmpleadosGenerica.add(empleadoJean);
        listaEmpleadosGenerica.add(empleado1);

        System.out.println("Ver lista mediante Notación Lambda:");
        listaEmpleadosGenerica.forEach(val -> System.out.println(val.getNombre() + val.getSalario()));

        System.out.println("****Reporte de Empleados en el Sistema Medico Universitario***");

        for (Empleado emp : listaEmpleadosGenerica) {
            System.out.println("Empleado: " + emp.getNombre() + " su salario es: " +"---->"+ emp.getSalario());

        }
    }

}
