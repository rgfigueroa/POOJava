/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

import java.util.GregorianCalendar;

/**
 *
 * @author roberth
 */
public class Empleado {

    private String nombre;
    private int horasDiarias;
    private GregorianCalendar fechaIngreso;    
    private double salario;

    public Empleado() {
    }

    public Empleado(String nombre, int horasDiarias, GregorianCalendar fechaIngreso) {
        this.nombre = nombre;
        this.horasDiarias = horasDiarias;
        this.fechaIngreso = fechaIngreso;
    }

    public Empleado(String nombre, int horasDiarias, GregorianCalendar fechaIngreso, double salario) {
        this.nombre = nombre;
        this.horasDiarias = horasDiarias;
        this.fechaIngreso = fechaIngreso;
        this.salario = salario;
    }

    public Empleado(String nombre, double salario) {
        this.nombre = nombre;
        this.salario = salario;
    }
    
    public Empleado(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the horasDiarias
     */
    public int getHorasDiarias() {
        return horasDiarias;
    }

    /**
     * @param horasDiarias the horasDiarias to set
     */
    public void setHorasDiarias(int horasDiarias) {
        this.horasDiarias = horasDiarias;
    }

    /**
     * @return the fechaIngreso
     */
    public GregorianCalendar getFechaIngreso() {
        return fechaIngreso;
    }

    /**
     * @param fechaIngreso the fechaIngreso to set
     */
    public void setFechaIngreso(GregorianCalendar fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    /**
     * @return the salario
     */
    public double getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double calcularSueldo() {
        System.out.println("Su sueldo básico es: " + this.salario);
        return this.salario;
    }

    public double calcularSueldoExtra(int numeroHoras) {
        System.out.println("Su sueldo extra es: " + numeroHoras * 10.00);
        return (numeroHoras * 10.00);
    }

}
