/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

/**
 *
 * @author roberth
 */
public class Secretaria extends Empleado {

    public Secretaria(String nombre, double salario) {
        super(nombre, salario);

    }

    public void facturar() {
        System.out.println("Soy la Secrearia y puedo facrurar");
    }
}
