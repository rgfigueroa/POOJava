/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

/**
 *
 * @author roberth
 */
public class Enfermera {

    private char asistirCirugia;

    /**
     * @return the asistirCirugia
     */
    public char getAsistirCirugia() {
        return asistirCirugia;
    }

    /**
     * @param asistirCirugia the asistirCirugia to set
     */
    public void setAsistirCirugia(char asistirCirugia) {
        this.asistirCirugia = asistirCirugia;
    }

}
