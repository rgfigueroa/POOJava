/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Date;

/**
 *
 * @author roberth
 */
public class CitaMedica {

    private int numeroTurno;
    private Date horaCita;
    private int duracion;
    private Paciente paciente;

    public CitaMedica(int numeroTurno, Date horaCita, int duracion, Paciente paciente) {
        this.numeroTurno = numeroTurno;
        this.horaCita = horaCita;
        this.duracion = duracion;
        this.paciente = paciente;
    }
    

    /**
     * @return the numeroTurno
     */
    public int getNumeroTurno() {
        return numeroTurno;
    }

    /**
     * @param numeroTurno the numeroTurno to set
     */
    public void setNumeroTurno(int numeroTurno) {
        this.numeroTurno = numeroTurno;
    }

    /**
     * @return the horaCita
     */
    public Date getHoraCita() {
        return horaCita;
    }

    /**
     * @param horaCita the horaCita to set
     */
    public void setHoraCita(Date horaCita) {
        this.horaCita = horaCita;
    }

    /**
     * @return the duracion
     */
    public int getDuracion() {
        return duracion;
    }

    /**
     * @param duracion the duracion to set
     */
    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    /**
     * @return the paciente
     */
    public Paciente getPaciente() {
        return paciente;
    }

    /**
     * @param paciente the paciente to set
     */
    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }
}
