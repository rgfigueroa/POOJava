/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Date;

/**
 *
 * @author roberth
 */
public class Paciente extends Persona {

    private int numeroHistoriaClinica;

    public Paciente(String identificacion, String nombre, Date fechaNacimiento, int numeroHistoriaClinica) {
        super(identificacion, nombre, fechaNacimiento);
        this.numeroHistoriaClinica = numeroHistoriaClinica;
    }

    /**
     * @return the numeroHistoriaClinica
     */
    public int getNumeroHistoriaClinica() {
        return numeroHistoriaClinica;
    }

    /**
     * @param numeroHistoriaClinica the numeroHistoriaClinica to set
     */
    public void setNumeroHistoriaClinica(int numeroHistoriaClinica) {
        this.numeroHistoriaClinica = numeroHistoriaClinica;
    }

}
