/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioarchivo2a;

import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author roberth
 */
public class Escribir {

    public static void main(String[] args) {
        try {
            // TODO code application logic here
            FileWriter fw = new FileWriter("Archivo2A.txt",true);
            fw.write("@@Productos:\n");
            fw.write("Libro\n");
            fw.write("Regla\n");
            fw.write("Lapiz");
            fw.close();

        } catch (IOException ex) {
            Logger.getLogger(Escribir.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("no se puede crear el archivo");

        }
    }

}
