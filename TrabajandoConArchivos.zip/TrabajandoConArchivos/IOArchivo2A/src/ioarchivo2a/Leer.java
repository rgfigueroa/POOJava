/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioarchivo2a;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author roberth
 */
public class Leer {

    public static void main(String[] args) {
        FileWriter fw;
        FileReader fr;
        int c;
        try {

            fw = new FileWriter("NuevoArchivo.txt");
            fr = new FileReader("Archivo2A.txt");

            while ((c = fr.read()) != -1) {
                System.out.println("El carctercer ascci es: " + c);

                fw.write(c);
            }
            fw.close();
            fr.close();
        } catch (IOException ex) {
            Logger.getLogger(Leer.class.getName()).log(Level.SEVERE, null, ex);      
            System.out.println("Error al trabajar con archivos");

        }
    }
}
