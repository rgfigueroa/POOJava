/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesarchivos;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author roberth
 */
public class ConSerializable implements Serializable {

    private static ConSerializable crearPunto() {
        System.out.println("crea punto");
        return null;
    }

    private int x;
    private int y;

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public static void main(String[] arg) {
        ConSerializable p = crearPunto();
        FileOutputStream fos;
        try {
            fos = new FileOutputStream("MiFicheroSerializado.txt");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(p);
            oos.close();
        } catch (FileNotFoundException ex) {
            System.out.println("archvio no encontrado");
        } catch (IOException ex) {
            System.out.println("error al utilizar el arhcivo");
        }

    }
}
