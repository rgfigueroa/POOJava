/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesarchivos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author roberth
 */
public class Lectura {

    File f = new File("achivo.txt");
    Scanner sc;

    public Lectura() {
        try {
            this.sc = new Scanner(f);
        } catch (FileNotFoundException ex) {
            System.out.println("Error FileNotFoundException");
        }
    }

}
