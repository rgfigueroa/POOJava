/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesarchivos;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author roberth
 */
public class UsoFileWriter {

    public static void main(String[] args) {
        UsoFileWriter ufw = new UsoFileWriter();
        // ufw.escribe_fichero();
        ufw.copia_fichero();
    }

    public void copia_fichero() {
        int c;
        try {
            FileReader in = new FileReader("fuente.txt");
            FileWriter out = new FileWriter("destino.txt");

            while ((c = in.read()) != -1) {
                out.write(c);
            }

            in.close();
            out.close();

        } catch (FileNotFoundException e1) {
            System.err.println("Error: No se encuentra el fichero");
        } catch (IOException e2) {
            System.err.println("Error leyendo/escribiendo fichero");
        }
    }

    public void escribe_fichero() {
        FileWriter out = null;
        PrintWriter p_out = null;

        try {
            out = new FileWriter("fuente.txt");
            p_out = new PrintWriter(out);
            p_out.println(
                    "Este texto será escrito en el fichero de salida");

        } catch (IOException e) {
            System.err.println("Error al escribir en el fichero");
        } finally {
            p_out.close();
        }
    }

}
