/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesarchivos;

import java.io.File;

/**
 *
 * @author roberth
 */
public class DeleteFolder {

    public static void main(String[] args) {
        File myObj = new File("/Users/roberth/NetBeansProjects/FilesArchivos");
        if (myObj.delete()) {
            System.out.println("Deleted the folder: " + myObj.getName());
        } else {
            System.out.println("Failed to delete the folder.");
        }
    }

}
