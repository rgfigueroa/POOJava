/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesarchivos;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;

/**
 *
 * @author roberth
 */
public class FilesArchivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            FileWriter fw = new FileWriter("archivoRoberth.txt");
            fw.write("Primer Texto");
            fw.close();
            FileReader fr = new FileReader("archivoRoberth.txt");
            System.out.println(fr.read());

        } catch (Exception e) {
            System.out.println("Error al crear al archivo");
        }
    }

}
