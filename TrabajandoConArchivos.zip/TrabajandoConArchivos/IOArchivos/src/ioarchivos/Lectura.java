/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioarchivos;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author roberth
 */
public class Lectura {

    public static void main(String[] args) {
        File miObjeto = new File("Datos.txt");

        try {
            Scanner entrada = new Scanner(miObjeto);
            entrada = new Scanner(miObjeto);
            
            while (entrada.hasNextLine()) {
                String data = entrada.nextLine();
                System.out.println(data);
            }
            entrada.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Lectura.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
