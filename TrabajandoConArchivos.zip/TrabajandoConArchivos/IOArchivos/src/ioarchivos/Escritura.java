/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioarchivos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author roberth
 */
public class Escritura {

    public static void main(String[] args) {

        try {
            FileWriter fw = new FileWriter("Datos.txt");
            fw.write("Cualquier Hola\n");
            fw.write("Linea 2\nHola Lenia 3");
            fw.write("\tHola Mundo");
            fw.close();
        } catch (IOException ex) {
            Logger.getLogger(Escritura.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
