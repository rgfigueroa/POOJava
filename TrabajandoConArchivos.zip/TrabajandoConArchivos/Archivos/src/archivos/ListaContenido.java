/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivos;

import java.io.*;

/**
 *
 * @author roberth
 */
public class ListaContenido {

    public static void main(String[] arg) {
        File ruta = new File("/Users/roberth/NetBeansProjects/Archivos/");
        System.out.println(ruta.getAbsolutePath());

        String[] listaArchivos = ruta.list();
        for (int i = 0; i < listaArchivos.length; i++) {
            System.out.println(i + ". " + listaArchivos[i]);
            File f = new File(ruta.getAbsolutePath(), listaArchivos[i]);
            if (f.isDirectory()) {
                String[] archivosSubcarpeta = f.list();
                for (int j = 0; j < archivosSubcarpeta.length; j++) {
                    System.out.println("\t"+j+"."+ archivosSubcarpeta[j]);
                }
            }
        }
    }

}
