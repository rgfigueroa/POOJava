package archivos;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author roberth
 */
public class ManejoArchivos {

    public static void main(String[] args) {
        try {
            File file = new File("MiArchivo.txt");
            file.createNewFile();
            System.out.println("Ubicación completa:" + file.getAbsolutePath());

          //  FileInputStream fis = new FileInputStream(file);

            FileOutputStream fos = new FileOutputStream(file);
            String mensaje = "Buenos días";
            fos.write(64);
            fos.write(65);

            byte[] bufferFlujo = new byte[10];

            bufferFlujo = mensaje.getBytes();

//            for (int i = 0; i < mensaje.length(); i++) {
//                fos.write(mensaje.charAt(i));
//            }
            fos.write(64);
            fos.write(bufferFlujo);
            fos.close();


//            byte[] buffer = new byte[10];
//            StringBuilder sb = new StringBuilder();
//
//            System.out.println(buffer);
//
//            while ((fis.read(buffer)) != -1) {
//                System.out.println("Impriendo en pantalla:"+buffer);
//                sb.append(new String(buffer));
//                buffer = new byte[10];
//            }
           // fis.close();

        } catch (IOException ex) {
            Logger.getLogger(ManejoArchivos.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
