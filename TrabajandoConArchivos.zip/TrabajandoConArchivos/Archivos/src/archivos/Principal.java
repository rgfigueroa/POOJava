/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 *
 * @author roberth
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    enum nacionalidad {
        Ecuador, Peru, Colombia, Mexico
    };

    enum TipoCliente{
        EXCELENTE, BAJO, ALTO
    };
    
    enum Genero{
        masculino, femenino
    };
    
    enum opciones{
        Ingresar,Eliminar,Consultar
    };
    
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            File f = new File("/Users/roberth/NetBeansProjects/Archivos/New.txt");

            FileInputStream fis = new FileInputStream(f);

            System.out.println("Abosulte:" + f.getAbsolutePath());

            if (f.isDirectory()) {
                f.delete();
            } else {
                System.out.println("No se pued borrar no es directorio");
            }

            FileOutputStream fos = new FileOutputStream("NuevoDocumento.txt");
            int c = 0;
            fos.write(64);

            fos.write(94);
            fos.write(244);
            String saludo = "Hola buenos dias! es un mensaje";
            System.out.println(saludo);
            byte b = (byte) 64;
            byte[] buffer = new byte[1];
            buffer = saludo.getBytes();
            System.out.println("Tamaño:" + buffer.length);
            fos.write(buffer);
            fos.write(b);

            while ((c = fis.read(buffer)) != -1) {
                System.out.println("Leido:" + c);
                 
            }
       

            nacionalidad EC = nacionalidad.Ecuador;
            nacionalidad PE = nacionalidad.Peru;
            nacionalidad MX = nacionalidad.Mexico;
            nacionalidad CO = nacionalidad.Colombia;
            
            opciones op= opciones.Consultar;
            
//            Genero g;
//
//            Persona p = new Persona(nombre, apellido, g.masculino);
//            
            
            System.out.println("nacionalidad: " + EC);

            String file = "archivo.txt";

            String respuesta = Archivos.LeerUsandoFileInputStream(file);
            System.out.println("El contenido es:\n" + respuesta);

        } catch (Exception e) {
            e.getMessage();
        }

    }

}
