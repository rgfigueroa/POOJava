/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivosio;

import java.io.FileWriter;
import java.io.IOException;


/**
 *
 * @author roberth
 */
public class ArchivosIO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // TODO code application logic here
            FileWriter fw = new FileWriter("Archivo2B.txt",true);
            fw.write(45);
            fw.write("Buenos dias\n");
            fw.write(42);
            fw.close();
        } catch (IOException ex) {
            System.out.println("Error al crear el archivo");
            System.out.println("Error tecnico: " + ex.getMessage());
        }
    }

}
