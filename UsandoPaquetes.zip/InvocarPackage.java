/*
     Descripcion: Llamado a una clase de un package
     Autor:roberth
     Fecha:25/11/2020
*/
import ProgramacionOO.Matematica.Calculadora;

public class InvocarPackage{
	public static void main(String[] args) {
		Calculadora calc= new Calculadora();
		calc.sumar(4,8);
		calc.restar(5,2);
	}
}