/*
    Descripcion: Aplicando el concepto de POO a una calculadora básica
    Autor: Roberth
    Fecha:11/11/2020
*/

package ProgramacionOO.Matematica;

public class Calculadora{
	//Atributos
	int numeroUno;
    int numeroDos;
    int resultado;
    
	//Metodos
    public void sumar(int n1, int n2){
    	resultado=n1+n2;
    	System.out.println("El resultado de la Suma es:"+ resultado);
    }
    public void restar(int min, int sus){
    	resultado=min-sus;
    	System.out.println("El resultado de la Resta es:"+ resultado);
    }

    // Agregar las 6 operaciones básicas a la calculadora
    //Potencia se hará mediante recursividad.
    //Mañana en clase se explicará.
}

/*
public class EjecutarCalculadora{
	public static void main(String[] args) {
		Calculadora c = new Calculadora();
		c.sumar(5,4);
	}
}
*/
