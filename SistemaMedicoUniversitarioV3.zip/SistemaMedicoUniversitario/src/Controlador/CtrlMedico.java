/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.CitaMedica;
import Modelo.Medico;
import Modelo.Paciente;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author roberth
 */
public class CtrlMedico {

    /**
     * Metodo que permite agendar una citaMedica a un medico señalado.
     *
     * @param medico
     * @param citaMedica
     * @return Retorna una lista de CitasMedicas
     */
    public Medico agendarCitaMedica(String identificacionM, String nombreM,String especilidad, Date fecha, CitaMedica citamedica) {

        Medico medico = new Medico(identificacionM, nombreM,fecha, especilidad, new ArrayList<CitaMedica>());  
        medico.getListadoCitasMedicas().add(citamedica);    
              
        return medico;

    }

    public ArrayList<CitaMedica> eliminarCitaMedica(Medico medico, CitaMedica citaMedica) {
        ArrayList<CitaMedica> listaCM = new ArrayList<>();
        medico.getListadoCitasMedicas().remove(citaMedica);
        return medico.getListadoCitasMedicas();
    }

}
