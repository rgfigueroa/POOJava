/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.CitaMedica;
import Modelo.Paciente;
import java.util.Date;

/**
 *
 * @author roberth
 */
public class CtrlPaciente {

    public Paciente registrarDatosPaciente(String identificacion, String nombre, Date fechaNacimiento, int numeroHistoriaClinica) {
        Paciente paciente = new Paciente(identificacion, nombre, fechaNacimiento, numeroHistoriaClinica);
        if (paciente != null) {
            System.out.println("Creado el paciente con los datos: " + identificacion + " --> Nombre:" + nombre);
        } else {
            System.out.println("No se pudo crear el Paciente " + identificacion + " --> Nombre:" + nombre);            
        }
        return paciente;
    }

}
