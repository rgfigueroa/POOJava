/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.CitaMedica;
import Modelo.Medico;
import Modelo.Paciente;
import java.util.Date;

/**
 *
 * @author roberth
 */
public class CtrlCitaMedica {

    public CitaMedica registrarDatosCitaMedica(int numeroTurno, Date horaCita, int duracion, Paciente paciente) {
        CitaMedica citamedica = new CitaMedica(numeroTurno, horaCita, duracion, paciente);
        return citamedica;
    }

    public void agendarCitaMedica(Medico medico, CitaMedica citaMedica) {

    }

    public void promocionSegundaCitaM(Medico medico, CitaMedica citaMedica) {

        //Logica de promocion
    }

}
