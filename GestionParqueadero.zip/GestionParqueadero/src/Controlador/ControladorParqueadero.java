/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Cliente;
import Modelo.InterfaceAcceso;
import Modelo.Lugar;
import Modelo.Parqueadero;
import java.util.ArrayList;

/**
 *
 * @author roberth
 */
public class ControladorParqueadero extends Parqueadero implements InterfaceAcceso {

    public ControladorParqueadero(String nombre, int capacidad, ArrayList<Lugar> conjuntolugares) {
        super(nombre, capacidad, conjuntolugares);
    }

    @Override
    public boolean acceso(Cliente cliente, String usuario, String contrasena) {
        if (cliente.getUsuario() == usuario && cliente.getClave() == contrasena) {
            System.out.println("Acceso correcto");
            return true;

        } else {
            System.out.println("Acceso correcto");
            return false;
        }

    }

}
