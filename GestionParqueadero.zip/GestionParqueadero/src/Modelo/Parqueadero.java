/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author roberth
 */
public class Parqueadero {

    private String nombre;
    private int capacidad;
    private ArrayList<Lugar> conjuntolugares;

    public Parqueadero(String nombre, int capacidad, ArrayList<Lugar> conjuntolugares) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.conjuntolugares = conjuntolugares;
    }

    /**
     * @return the capacidad
     */
    public int getCapacidad() {
        return capacidad;
    }

    /**
     * @param capacidad the capacidad to set
     */
    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    /**
     * @return the conjuntolugares
     */
    public ArrayList<Lugar> getConjuntolugares() {
        return conjuntolugares;
    }

    /**
     * @param conjuntolugares the conjuntolugares to set
     */
    public void setConjuntolugares(ArrayList<Lugar> conjuntolugares) {
        this.conjuntolugares = conjuntolugares;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
