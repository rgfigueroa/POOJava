/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Paciente;
import java.util.Date;

/**
 *
 * @author roberth
 */
public class ControladorPaciente extends Paciente{

    public ControladorPaciente(String nombre, Date fechaNacimiento) {
        super(nombre, fechaNacimiento);
    }
}
