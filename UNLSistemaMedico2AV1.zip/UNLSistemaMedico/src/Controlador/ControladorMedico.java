/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Medico;
import java.util.Date;

/**
 *
 * @author roberth
 */
public class ControladorMedico extends Medico {

    public ControladorMedico(String nombre, Date fechaNacimiento, double sueldo, int matriculaP) {
        super(nombre, fechaNacimiento, sueldo, matriculaP);
    }
}
