/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Persona;
import java.util.Date;

/**
 *
 * @author roberth
 */
public class ControladorPersona extends Persona {

    public ControladorPersona(String nombre, Date fechaNacimiento) {
        super(nombre, fechaNacimiento);
    }

    @Override
    public void calcularEdadActual(Date fechaNacimiento) {
        System.out.println("Dentro de Objeto ControladorPersona en metodo calcularEdadActual" + this.getNombre()
                + this.getFechaNacimiento() + "  " + this.getClass().getName());

    }
}
