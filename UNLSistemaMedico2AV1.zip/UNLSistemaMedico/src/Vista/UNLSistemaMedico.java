/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.ControladorEmpleado;
import Controlador.ControladorMedico;
import Controlador.ControladorPaciente;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 *
 * @author roberth
 */
public class UNLSistemaMedico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        Date fechaNacimiento;
        GregorianCalendar gc = new GregorianCalendar();
        fechaNacimiento = gc.getTime();
         
        System.out.println("ingresa el año de nacimiento: ");
        int anioNacimiento = sc.nextInt();
        int anioActual= Calendar.getInstance().get(0);
        
        int edad = anioActual-anioNacimiento;
        System.out.println("TU EDAD es: "+ edad);



        System.out.println("Fecha del sistema: " + fechaNacimiento);

        String f = fechaNacimiento.toString();
        System.out.println("String f:" + f);

        Controlador.ControladorEmpleado ctrlEmpleado = new ControladorEmpleado("Empleado ABC", fechaNacimiento, 100.50);
        ctrlEmpleado.calcularEdadActual(fechaNacimiento);

        Controlador.ControladorPersona ctrlPersona = new Controlador.ControladorPersona("Persona ABC", fechaNacimiento);
        ctrlPersona.calcularEdadActual(fechaNacimiento);

        Controlador.ControladorPaciente ctrlPaciente = new Controlador.ControladorPaciente("Nom", fechaNacimiento);
        ctrlPaciente.calcularEdadActual(fechaNacimiento);

        ControladorMedico ctrlMedico = new ControladorMedico("Dr. Perez", fechaNacimiento, 200.00, 54207);
        ctrlMedico.calcularEdadActual(fechaNacimiento);
        
        

    }

}
