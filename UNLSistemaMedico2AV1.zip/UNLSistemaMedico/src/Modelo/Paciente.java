/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 *
 * @author roberth
 */
public class Paciente extends Persona {

    private HistoriaClinica historiaClinica;

    public Paciente(String nombre, Date fechaNacimiento) {
        super(nombre, fechaNacimiento);
        int codigoAleatorioHistoria;
        codigoAleatorioHistoria = (int) (Math.random() * 100);
        System.out.println("Codigo historia generado aleatoriamente:" + codigoAleatorioHistoria);
    }

    @Override
    public void calcularEdadActual(Date fechaNaciemto) {
        System.out.println("Calculando la Edad Actual de Paciente Hoy Vierns 10:00");
               
        Date fechaSistema;
        GregorianCalendar gc = new GregorianCalendar();
        fechaSistema = gc.getTime();
         
        int anioActual= Calendar.getInstance().get(0);
        
//      int edad = fechaSistema.getYear(anioActual) - fechaNaciemto;
      System.out.println("TU EDAD es: ");
         
    }

    /**
     * @return the historiaClinica
     */
    public HistoriaClinica getHistoriaClinica() {
        return historiaClinica;
    }

    /**
     * @param historiaClinica the historiaClinica to set
     */
    public void setHistoriaClinica(HistoriaClinica historiaClinica) {
        this.historiaClinica = historiaClinica;
    }

}
