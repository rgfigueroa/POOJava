/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author roberth
 */
public class HistoriaClinica {

    private int historiaClinica;

    public HistoriaClinica(int historiaClinica) {
        this.historiaClinica = historiaClinica;
    }

    /**
     * @return the historiaClinica
     */
    public int getHistoriaClinica() {
        return historiaClinica;
    }

    /**
     * @param historiaClinica the historiaClinica to set
     */
    public void setHistoriaClinica(int historiaClinica) {
        this.historiaClinica = historiaClinica;
    }

}
