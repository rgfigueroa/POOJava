/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author roberth
 */
public class ConexionBD {

    Connection conexion;

    public ConexionBD() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("El driver si se ubica correctamente");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/BD2B", "root", "root");

        } catch (ClassNotFoundException ex) {
            System.out.println("El driver no se encuntra");
            Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            System.out.println("No se puede conectar a la BD, revisar el server, user, pass");
            JOptionPane.showMessageDialog(null, "No se puede conectar a la BD, revisar el server, user, pass");
            Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {

        ArrayList arrayDatos = new ArrayList<>();
       

        ConexionBD con = new ConexionBD();
        Statement st;
        ResultSet rs;
        try {
            st = con.conexion.createStatement();
            rs = st.executeQuery("select * from producto");

            while (rs.next()) {
                System.out.println(rs.getString("nombre") + "\t" + rs.getString("descripcion") + "\t" + rs.getInt("cantidad"));

                //guardo el resultado en una variable de tipo array para utilizarlo en cualquier parte del programa.
                arrayDatos.add(rs.getString("nombre"));
            }

            con.conexion.close();
            //Recorro para presentar la variable array que ha sido cargado con los datos de la consulta de la DB realizada.
            for (Object dato : arrayDatos) {
                System.out.println("Datos tipo Objeto" + dato.toString());
            }

        } catch (SQLException ex) {
            System.out.println("No se pudo realizar la conexion");
            Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
