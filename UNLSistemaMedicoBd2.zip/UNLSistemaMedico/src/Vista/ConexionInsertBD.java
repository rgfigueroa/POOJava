/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author roberth
 */
public class ConexionInsertBD {

    Connection conexion;

    public ConexionInsertBD() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/BD2B", "root", "root");

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionInsertBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionInsertBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        ConexionInsertBD con = new ConexionInsertBD();
        boolean bandera = true;
        String sql = "insert into producto (nombre, descripcion, cantidad, precio,marca) values (?,?,?,?,?)";
        PreparedStatement ps = null;
        try {

            ps = con.conexion.prepareStatement(sql);
            System.out.println("PStamente creado");
            ps.setString(1, "Monitos 15 Gamer");
            ps.setString(2, "procesador Intel i9 16 GB Ram");
            ps.setInt(3, 8);
            ps.setDouble(4, 1940.38);
            ps.setString(5, "Lenovo");
            bandera = ps.execute();
            System.out.println("bandera" + bandera);
            if (bandera != true) {
                System.out.println("Se inserto una nueva fila correctamente");
            } else {
                System.out.println("No se  inserto, verificar");
            }
            ps.close();
            con.conexion.close();

        } catch (SQLException ex) {
            System.out.println("Error en la sentencia SQL, no se pudo insertar" + ex.getMessage());
            Logger.getLogger(ConexionInsertBD.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
