/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.ControladorArchivo;
import Controlador.ControladorEdificio;
import Controlador.ControladorPropietario;
import Modelo.Departamento;
import Modelo.Edificio;
import Modelo.Propietario;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author roberth
 */
public class GestionDepartametos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean respuesta = false;
        Scanner sc = new Scanner(System.in);

        ArrayList<Departamento> listaDepartamento = new ArrayList<>();

        ArrayList<Propietario> listaPropietarioA = new ArrayList<>();
        ArrayList<Propietario> listaPropietarioB = new ArrayList<>();
        ArrayList<Propietario> listaPropietarioC = new ArrayList<>();
        ArrayList<Propietario> listaPropietarioD = new ArrayList<>();

        Edificio edificio = new Edificio("Edificio UNL", "Av. Pio Jaramillo", listaDepartamento);

        Departamento departamentoA = new Departamento("DepA", 1, listaPropietarioA);
        Departamento departamentoB = new Departamento("DepB", 2, listaPropietarioB);
        Departamento departamentoC = new Departamento("DepC", 3, listaPropietarioC);
        Departamento departamentoD = new Departamento("DepD", 4, listaPropietarioD);

        Propietario propietarioJuan = new Propietario("Juan", "juanito", "12345");
        Propietario propietarioMaria = new Propietario("Maria", "maria", "12345");
        Propietario propietarioMiguel = new Propietario("Miguel", "miguel", "12345");
        Propietario propietarioDanny = new Propietario("DAnny", "danny", "12345");
        Propietario propietarioLizbeth = new Propietario("Lizbeth", "lizbeth", "12345");

        listaPropietarioA.add(propietarioJuan);
        listaPropietarioD.add(propietarioMaria);
        listaPropietarioB.add(propietarioMiguel);
        listaPropietarioA.add(propietarioDanny);
        listaPropietarioD.add(propietarioLizbeth);

        departamentoA.setListaPropietario(listaPropietarioA);
        departamentoB.setListaPropietario(listaPropietarioB);
        departamentoC.setListaPropietario(listaPropietarioC);
        departamentoD.setListaPropietario(listaPropietarioD);
        

        listaDepartamento.add(departamentoA);
        listaDepartamento.add(departamentoB);
        listaDepartamento.add(departamentoC);
        listaDepartamento.add(departamentoD);

        edificio.setListaDepartamento(listaDepartamento);

        System.out.println("******** Edicio: ********" + edificio.getNombre());

        for (Departamento d : listaDepartamento) {
            System.out.println("Departemento: " + d.getNombre());
            for (Propietario pd : d.getListaPropietario()) {
                System.out.println("\tPropietario: " + pd.getNombre());
                System.out.println("\tSu usuario: " + pd.getUsuario());
                System.out.println("\tSu clave: " + pd.getClave());
            }
        }
        ControladorPropietario ctrlPropietario = new ControladorPropietario();

        //validar acceso
        respuesta = ctrlPropietario.ingresar(propietarioDanny, "danny", "12345");
        if (respuesta) {
            System.out.println("Bienvenido!!");
        } else {
            System.out.println("Incorrecto!!");
        }

        //Escribiendo en el archivo
        Controlador.ControladorArchivo ctrlArchivo= new ControladorArchivo();
        ctrlArchivo.escribirEnArchivo(listaDepartamento);
        ctrlArchivo.leerEnArchivo();
        ctrlArchivo.leerElArchivoScanner();
    }

}
