/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Departamento;
import Modelo.Edificio;
import Modelo.Propietario;
import java.util.ArrayList;

/**
 *
 * @author roberth
 */
public class ControladorEdificio {
    
    Edificio edificio;  

    public ControladorEdificio(Edificio edificio) {
        this.edificio = edificio;     
    }
    
    public void asignarPropietario(Departamento departamento, ArrayList<Propietario> listaPropietario){
        departamento.setListaPropietario(listaPropietario);    
        System.out.println("Asignanda lista de propietarios");
    }
    

}
