/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Departamento;
import Modelo.Propietario;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author roberth
 */
public class ControladorArchivo {

    public void escribirEnArchivo(ArrayList<Departamento> listaDepartamento) {
        FileWriter fw;
        try {
            fw = new FileWriter("InfoDepartamentos.txt", true);
            fw.write("Escribiendo en el archivo\n");
            fw.write("Algo mas");
            for (Departamento d : listaDepartamento) {
                fw.write("Departemento: " + d.getNombre() + "\n");
                for (Propietario p : d.getListaPropietario()) {
                    fw.write("\tPropietario: " + p.getNombre() + "\n");
                    fw.write("\tSu usuario: " + p.getUsuario() + "\n");
                    fw.write("\tSu clave: " + p.getClave() + "\n");
                }
            }
            fw.close();

        } catch (IOException e) {
            System.out.println("No se pudo crear el archivo para la escritura");
        }
    }

    public void escribirEnArchivo(Object listaDepartamento) {

    }

    public void leerEnArchivo() {
        System.out.println("LEYENDO");
        File archivo;
        BufferedReader br;
        String s = null;
        try {
            archivo = new File("InfoDepartamentos.txt");
            br = new BufferedReader(new FileReader(archivo));
            while ((s = br.readLine()) != null) {
                System.out.println(s);

            }
            br.close();
        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {
            Logger.getLogger(ControladorArchivo.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Archivo no lo encontro");
        }

    }

    public void leerElArchivoScanner() {
        //Leyendo en el archivo.
        // FileReader fr;
        File f = new File("InfoDepartamentos.txt");
        Scanner sc;
        String texto = null;
        System.out.println("Comienzo a leer el ARCHIVO CON CLASE SCANNER");

        try {
            sc = new Scanner(f);
            while (sc.hasNextLine()) {
                texto = sc.nextLine();

                System.out.println(texto);
            }
            sc.close();

        } catch (Exception e) {
            System.out.println("Error no se encuentra el archivo para lectura");
        }

    }
}
