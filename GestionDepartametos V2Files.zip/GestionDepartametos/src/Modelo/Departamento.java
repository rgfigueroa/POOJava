/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author roberth
 */
public class Departamento {

    private String nombre;
    private int numeroDepartamento;
    private ArrayList<Propietario> listaPropietario;

    public Departamento(String nombre, int numeroDepartamento, ArrayList<Propietario> listaPropietario) {
        this.nombre = nombre;
        this.numeroDepartamento = numeroDepartamento;
        this.listaPropietario = listaPropietario;
    }

    /**
     * @return the listaPropietario
     */
    public ArrayList<Propietario> getListaPropietario() {
        return listaPropietario;
    }

    /**
     * @param listaPropietario the listaPropietario to set
     */
    public void setListaPropietario(ArrayList<Propietario> listaPropietario) {
        this.listaPropietario = listaPropietario;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the numeroDepartamento
     */
    public int getNumeroDepartamento() {
        return numeroDepartamento;
    }

    /**
     * @param numeroDepartamento the numeroDepartamento to set
     */
    public void setNumeroDepartamento(int numeroDepartamento) {
        this.numeroDepartamento = numeroDepartamento;
    }

}
