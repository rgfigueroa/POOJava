/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Cliente;
import Modelo.Lugar;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author roberth
 */
public class ControladorArchivo {

    public void escribirEnArchivo(ArrayList<Lugar> lugares) {
        FileWriter fw;

        try {
            fw = new FileWriter("InfoParqueadero.txt", true);
            fw.write("Archivo de informacion de PARQUEADERO\n");
            for (Lugar l : lugares) {
                System.out.println("Lugar #: " + l.getNumero());
                fw.write("Lugar #: " + l.getNumero() + "\n");
                for (Cliente c : l.getListaCliente()) {
                    System.out.println("\tCliente: " + c.getNombre());
                    fw.write("\tCliente: " + c.getNombre() + "\n");
                    System.out.println("\tSu usuario: " + c.getUsuario());
                    fw.write("\tSu usuario: " + c.getNombre() + "\n");
                    System.out.println("\tSu clave: " + c.getClave());
                    fw.write("\tSu clave: " + c.getClave() + "\n");
                }
            }
            fw.close();
        } catch (IOException e) {
            System.out.println("Error al crear el archivo");
        } finally {
            System.out.println("Cerrando archivo con close()");
        }
    }

    public void escribirEnArchivo(Object lugares) {

    }

    public void leerElArchivo() {
        //Leyendo en el archivo.
        // FileReader fr;
        File f = new File("InfoParqueadero.txt");
        Scanner sc;
        String texto = null;
        System.out.println("Comienzo a leer el ARCHIVO");
        
        try {
            sc = new Scanner(f);
            while (sc.hasNextLine()) {
                texto = sc.nextLine();
                
                System.out.println(texto);
            }
            sc.close();
            
        } catch (Exception e) {
            System.out.println("Error no se encuentra el archivo para lectura");
        }

    }

}
