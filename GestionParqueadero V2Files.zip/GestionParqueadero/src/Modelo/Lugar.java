/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author roberth
 */
public class Lugar {

    private int numero;
    private ArrayList<Cliente> listaCliente;

    public Lugar(int numero, ArrayList<Cliente> listaCliente) {
        this.numero = numero;
        this.listaCliente = listaCliente;
    }

    /**
     * @return the listaCliente
     */
    public ArrayList<Cliente> getListaCliente() {
        return listaCliente;
    }

    /**
     * @param listaCliente the listaCliente to set
     */
    public void setListaCliente(ArrayList<Cliente> listaCliente) {
        this.listaCliente = listaCliente;
    }

    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

}
