/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.ControladorArchivo;
import Controlador.ControladorParqueadero;
import Modelo.Cliente;
import Modelo.Lugar;
import Modelo.Parqueadero;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author roberth
 */
public class GestionParqueadero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeroL = 0;
        String nombreC = "";

        ArrayList<Lugar> listaLugares = new ArrayList<>();
        ArrayList<Cliente> listaCliente1 = new ArrayList<>();
        ArrayList<Cliente> listaCliente2 = new ArrayList<>();
        ArrayList<Cliente> listaCliente3 = new ArrayList<>();
        ArrayList<Cliente> listaCliente4 = new ArrayList<>();

        ControladorParqueadero ctrlParqueadero = new ControladorParqueadero("Parqueadero UNL", 50, listaLugares);

        Cliente c1 = new Cliente("Juan", "juan", "12345");
        Cliente c2 = new Cliente("Maria", "maria", "12345");
        Cliente c3 = new Cliente("Pedro", "pedro", "12345");
        Cliente c4 = new Cliente("Ana", "ana", "55555");
        Cliente c5 = new Cliente("Luis", "luis", "55555");

        //  Cliente que se agregan a la lista 1 y lista 2
        listaCliente1.add(c1);
        listaCliente1.add(c3);
        listaCliente2.add(c2);
        listaCliente3.add(c4);
        listaCliente4.add(c5);

        Lugar l1 = new Lugar(1, listaCliente1);
        Lugar l2 = new Lugar(2, listaCliente2);
        Lugar l3 = new Lugar(3, listaCliente3);
        Lugar l4 = new Lugar(4, listaCliente4);

        listaLugares.add(l1);
        listaLugares.add(l2);
        listaLugares.add(l3);
        listaLugares.add(l4);

        System.out.println("Recorrido de la información: ");

        ctrlParqueadero.setConjuntolugares(listaLugares);

        for (Lugar l : listaLugares) {
            System.out.println("Lugar #: " + l.getNumero());
            for (Cliente c : l.getListaCliente()) {
                System.out.println("\tCliente: " + c.getNombre());
                System.out.println("\tSu usuario: " + c.getUsuario());
                System.out.println("\tSu clave: " + c.getClave());
            }
        }

        System.out.println("ESCRIBIENDO EN EL ARCHIVO: ");

        ControladorArchivo ctrlArchivo = new ControladorArchivo();
        ctrlArchivo.escribirEnArchivo(listaLugares);

        System.out.println("LEYENDO EL ARCHIVO : ");
        ctrlArchivo.leerElArchivo();

        //       ControladorParqueadero ctrlParqueadero = new ControladorParqueadero("Parqueadero UNL", 50, listaLugares);
//
//       
//        Scanner sc = new Scanner(System.in);
//        System.out.println("====================== MENU SISTEMA PARQUEADERO ======================");
//
//        int opcion = 0;
//        try {
//            do {
//                System.out.println("==== 1. Registrar información                 ====");
//                System.out.println("==== 2. Eliminar Información                  ====");
//                System.out.println("==== 3. Mostrar datos de Lugar y Clientes ====");
//                System.out.println("==== 4. Guardar información en Archivo        ====");
//                System.out.println("==== 5. Salir                                 ====");
//                System.out.println("==================================================");
//
//                opcion = sc.nextInt();
//                switch (opcion) {
//                    case 1:
//                        System.out.println("En 1. Registrar información");
//                         {
//                            int op = 0;
//
//                            do {
//                                System.out.println("==== 1. Registrar Informacion Parqueadero ====");
//                                System.out.println("==== 2. Registrar el .....   ====");
//                                System.out.println("==== 3. Regresar al menu anterior        ====");
//
//                                op = sc.nextInt();
//                                switch (op) {
//                                    case 1:
//                                        try {
//
//                                            System.out.println("*** Ingresando informacion del parqueadero ***");
//
////                                            ctrlParqueadero.setConjuntolugares(listaLugares);
////                                            listaLugares.get(0).getListaCliente();
//                                            Cliente c = new Cliente("", "", "");
//                                            System.out.println("Nombre Cliente");
//                                            nombreC = sc.next();
//                                            c.setNombre(nombreC);
//                                            System.out.println("Usuario del Cliente");
//                                            nombreC = sc.next();
//                                            c.setUsuario(nombreC);
//                                            System.out.println("Contraseña del Cliente");
//                                            nombreC = sc.next();
//                                            c.setClave(nombreC);
//                                            listaCliente.add(c);
//
//                                            System.out.println("Creacion de Lugares");
//                                            nombreC = sc.next();
//                                            c.setNombre(nombreC);
//                                            System.out.println("Numero del Lugar");
//                                            nombreC = sc.next();
//                                            c.setUsuario(nombreC);
//
//                                            //
//                                            System.out.println("Nombre Parqueadero");
//                                            String identificacionP = sc.next();
//                                            System.out.println("Capacidad");
//                                            String nombreP = sc.next();
//                                            System.out.println("Ingresar los lugares del parqueadero:");
//                                            for (Lugar lugar : listaLugares) {
//                                                System.out.println("Ingresa el numero del Lugar:");
//                                                numeroL = sc.nextInt();
//                                                lugar.setNumero(numeroL);
//                                                //   lugar.getListaCliente().add(cliente);
//
//                                            }
//                                            int NumeroHistoriaClinica = sc.nextInt();
//                                            //Crea un paciente
//                                            //     paciente = crtlPaciente.registrarDatosPaciente(identificacionP, nombreP, fecha, NumeroHistoriaClinica);
//                                            System.out.println("*** Ingresando informacion de la Cita Medica ***");
//                                            System.out.println("Turno");
//                                            int turnoC = sc.nextInt();
//                                            System.out.println("Hora cita cogiendo del sistema");
//                                            System.out.println("Duracion de la cita:");
//                                            int duracionCM = sc.nextInt();
//                                            //Creaar la CitaMedica
//                                            //     citamedica = ctrlCitaMedicaP.registrarDatosCitaMedica(turnoC, fecha, duracionCM, paciente);
//
//                                        } catch (Exception e) {
//                                            e.getMessage();
//                                        }
//                                    case 2:
//                                        try {
//
//                                            //Para recorrer
//                                            for (Lugar l : listaLugares) {
//                                                System.out.println("Departemento: " + l.getNumero());
//                                                for (Cliente c : l.getListaCliente()) {
//                                                    System.out.println("\tPropietario: " + c.getNombre());
//                                                    System.out.println("\tSu usuario: " + c.getUsuario());
//                                                    System.out.println("\tSu clave: " + c.getClave());
//                                                }
//                                            }
//
//                                            //      ControladorPropietario ctrlPropietario = new ControladorPropietario();
//                                            System.out.println("*** Ingresando informacion del Medico para la Cita *** ");
//                                            System.out.println("Identificacion Medico");
//                                            String identificacionM = sc.next();
//                                            System.out.println("Nombre");
//                                            String nombreM = sc.next();
//                                            System.out.println("especialidad");
//                                            String especilidad = sc.next();
//
//                                            // Crear el Medico
//                                            // medicos = ctrlMedico.agendarCitaMedica(identificacionM, nombreM, especilidad, fecha, citamedica);
//                                            System.out.println("Creado la cita exitosmanete");
//                                            //    listaMedicos.add(medicos);
//
//                                        } catch (Exception e) {
//                                            e.getMessage();
//                                        }
//
//                                }
//                            } while (op != 3);
//                        }
//                        break;
//
//                    case 2:
//                        System.out.println("En 2. Eliminar Información");
//                        break;
//                    case 3:
//                        System.out.println("En 3. Mostrar datos de medicos y cita medicas");
////                        for (Medico medico : listaMedicos) {
////                            System.out.println("Medico: " + medico.getNombre() + " " + medico.getEspecialidad());
////                            System.out.println("Lista las Cita Medicas agendadas: ");
////                            System.out.println("Usando un for de objetos: ");
////                            for (CitaMedica c : medico.getListadoCitasMedicas()) {
////                                System.out.println("Cita" + c.getPaciente().getNombre() + " " + c.getHoraCita());
////                            }
////                            System.out.println("Usando un for mediante Notación Lambda: ");
////                            medico.getListadoCitasMedicas().forEach(lc -> System.out.println(lc.getPaciente().getNombre()));
////
////                        }
//
//                        break;
//                    case 4:
//                        System.out.println("En 4. Implemtar Guardar información en Archivo");
//                        break;
//                    case 5:
//                        System.out.println("En 5. Salir");
//                        break;
//                    default:
//                        System.err.println("Opcion no valida, vuelva a Seleccionar");
//                }
//            } while (opcion != 5);
//
//        } catch (ArithmeticException ex) {
//            System.out.println("El formato ingresado del dato es incorrecto\n" + ex.getMessage());
//        } catch (Exception e) {
//            System.out.println("Ocurrio un error que debes controlar" + e.getMessage());
//        }
//
    }

}
