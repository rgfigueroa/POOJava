/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.ControladorEmpleadoOp2;
import Modelo.Medico;

/**
 *
 * @author roberth
 */
public class UNLSistemaMedico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

       // Medico medico = new Medico("Dr.Juan", 100.00, 4759);
        Controlador.ControladorEmpleadoOp2 ctrlEmpleadoDos = new ControladorEmpleadoOp2("Empleado",20.0);
        ctrlEmpleadoDos.calcularsueldo(70.0);
    }

}
