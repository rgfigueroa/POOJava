/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Empleado;

/**
 *
 * @author roberth
 */
public class ControladorEmpleadoOp2 extends Empleado {

    public ControladorEmpleadoOp2(String nombre, double sueldo) {
        super(nombre, sueldo);

    }

    public void solicitudVaciones() {
        System.out.println("Aqui calcular sueldo");

    }

}
