/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author roberth
 */
public class Empleado extends Persona {

    private double sueldo;

    public Empleado(String nombre, double sueldo) {
        super(nombre);
        this.sueldo = sueldo;
    }

    /**
     * @return the sueldo
     */
    public double getSueldo() {
        return sueldo;
    }

    /**
     * @param sueldo the sueldo to set
     */
    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    @Override
    public void calcularsueldo(double monto ) {
        //logica de como calcular el suledo para cada empleado
        //aqui escribir la logica por ser una clase abastract
        System.out.println("Aquei calcular sueldo" + monto);
    }

    @Override
    public void calcularsueldoExtra(int horas) {
        
        double sueldo= horas*10;
        System.out.println("El sueldo extra");

    }

}
