/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author roberth
 */
public class Medico extends Empleado implements InterfaceTurno{

    private int matriculaP;

    public Medico(String nombre, double sueldo, int matriculaP) {
        super(nombre, sueldo);
        this.matriculaP = matriculaP;
    }

    /**
     * @return the matriculaP
     */
    public int getMatriculaP() {
        return matriculaP;
    }

    /**
     * @param matriculaP the matriculaP to set
     */
    public void setMatriculaP(int matriculaP) {
        this.matriculaP = matriculaP;
    }

    @Override
    public void reservarTurno(int hc) {
        
    }

    @Override
    public void eliminarTurno() {
    }

    @Override
    public void pagarTurno() {
    }

}
