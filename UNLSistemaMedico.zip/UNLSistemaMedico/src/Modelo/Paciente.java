/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author roberth
 */
public class Paciente extends Persona {

    HistoriaClinica historiaClinica;
    public Paciente(String nombre, HistoriaClinica hc) {
        super(nombre);
        this.historiaClinica= hc;
    }

    @Override
     public void calcularsueldo(double monto ) {
    }

    @Override
   public void calcularsueldoExtra(int horas) {
    }

}
