/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;

/**
 *
 * @author roberth
 */
public class ConexionInsert {

    Connection con;

    public ConexionInsert() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/BD2B", "root", "root");
        } catch (ClassNotFoundException ex) {
            System.out.println("No se encuentra el Driver de conexion");
            Logger.getLogger(ConexionInsert.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            System.out.println("Revisar los datos de conexion imposible conectar con la BD");
            Logger.getLogger(ConexionInsert.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        System.out.println("Porbamos la conexion");
        ConexionInsert conI = new ConexionInsert();
        String sql;
        int fila ;
        PreparedStatement prepSt;
        try {
            sql = "insert into producto(nombre, descripcion, cantidad,precio, marca) values (?,?,?,?,?)";
            prepSt = conI.con.prepareStatement(sql);
            prepSt.setString(1, "Monitor");
            prepSt.setString(2, "Samsung");
            prepSt.setInt(3, 7);
            prepSt.setDouble(4, 345.95);
            prepSt.setString(5, "Huawei");
            fila = prepSt.executeUpdate();
            if (fila > 0) {
                System.out.println("Se ha insertado la fila correctamente");
            }
            prepSt.close();
            conI.con.close();

        } catch (SQLException e) {
            System.out.println("Error en la sentencia SQL, no se pudo insertar" + e.getMessage());
        }

    }

}
