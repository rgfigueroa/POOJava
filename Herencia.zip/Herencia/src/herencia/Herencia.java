/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author roberth
 */
public class Herencia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Circulo circulo = new Circulo();

        System.out.println("Imprimiendo informacion: " + circulo.radio);
        circulo.perimetro();

        Cubo cubo = new Cubo();
        Cubo cubo2 = new Cubo();
        System.out.println("Imprimiendo informacion Cubo: " + cubo.aristas);
        System.out.println("Imprimiendo informacion: " + cubo.lado);

        System.out.println("Imprimiendo informacion del cubo 2: " + cubo2.lado);

        cubo.volumen();
        cubo.area();
    }

}
