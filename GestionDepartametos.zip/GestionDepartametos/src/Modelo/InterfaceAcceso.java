/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author roberth
 */
public interface InterfaceAcceso {
    public boolean ingresar(Propietario propietario, String usuario, String clave); // Solamente implemento este metodo
    public void cambiarClave();
    
}
