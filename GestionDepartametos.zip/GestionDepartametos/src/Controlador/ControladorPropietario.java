/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.InterfaceAcceso;
import Modelo.Propietario;

/**
 *
 * @author roberth
 */
public class ControladorPropietario extends Propietario implements InterfaceAcceso {

    public ControladorPropietario(String nombre, String usuario, String clave) {
        super(nombre, usuario, clave);
    }

    public ControladorPropietario() {
        super(null, null, null);
    }
    
    @Override
    public boolean ingresar(Propietario propietario, String usuario, String clave) {
        
        if (propietario.getUsuario() == usuario && propietario.getClave() == clave) {
            System.out.println("acceso correcto");
            return true;
        } else {
            System.out.println("Acceso Incorrecto");
            return false;
        }
    }

    @Override
    public void cambiarClave() {

    }

}
