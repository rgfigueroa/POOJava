/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

/**
 *
 * @author roberth
 */
public class Guardia extends Empleado implements InterfaceSueldoExtra{

    public Guardia(String nombre, int horasDiarias, double salario) {
        super(nombre, horasDiarias, salario);
    }

    @Override
    public double calcularSueldoExtra(int numeroHoras) {
         System.out.println("Sueldo Sr Guardia"+numeroHoras*3.50);
          return numeroHoras*3.50;
    }

    @Override
    public double calcularDescuentosAtrasos(int numeroHoras) {
         return numeroHoras*2.00;
    }
    
}
