/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

import java.util.ArrayList;

/**
 *
 * @author roberth
 */
public class HerenciaHospitalUniversitario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        ArrayList<Empleado> listaEmpleados = new ArrayList<>();
        Empleado empleado = new Empleado("Juan", 10, 300.00);
        Conductor conductor = new Conductor("Conductor XY", 6, 200);
        Medico medico = new Medico("Pediatra", "Dr Juan ", 8, 700.00);

        conductor.calcularSueldo();

        medico.calcularSueldo();
        medico.calcularSueldoExtra(10);

        Enfermera enferma = new Enfermera("Maria", 10, 350);
        enferma.calcularSueldo();
        enferma.calcularSueldoExtra(10);

        Secretaria secretaria = new Secretaria("Secretaria", 7, 153.00);
        secretaria.calcularSueldo();
        //secretaria.calcularSueldoExtra(10);

        Guardia g = new Guardia("Sr Guardia", 8, 370);
        g.calcularSueldoExtra(10);

    }

}
