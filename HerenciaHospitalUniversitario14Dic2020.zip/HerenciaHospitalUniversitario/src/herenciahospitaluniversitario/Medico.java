/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciahospitaluniversitario;

import java.util.GregorianCalendar;

/**
 *
 * @author roberth
 */
public class Medico extends Empleado implements InterfaceSueldoExtra {

    private String especialidad;

    public Medico(String especialidad, String nombre, int horasDiarias, double salario) {
        super(nombre, horasDiarias, salario);
        this.especialidad = especialidad;
    }

    /**
     * @return the especialidad
     */
    public String getEspecialidad() {
        return especialidad;
    }

    /**
     * @param especialidad the especialidad to set
     */
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public void operar() {
        System.out.println("Este es el metodo operar()");
    }

    public void recetar() {
        System.out.println("Este es el metodo recetar()");
        System.out.println("Por favor tomar Paracetamol 500mg");
    }

    @Override
    public double calcularSueldoExtra(int numeroHoras) {
        System.out.println("Sueldo Extra a cancelar"+numeroHoras * 50.00);
        return numeroHoras * 50.00;
        
    }

    @Override
    public double calcularDescuentosAtrasos(int numeroHoras) {
        double descuento= numeroHoras*10.00;
        return descuento;

    }

}
